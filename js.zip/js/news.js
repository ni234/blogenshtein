function showResponse(response) {
    var responseString = JSON.stringify(response, '', 2);
    document.getElementById('response').innerHTML += responseString;
}


var xhr = new XMLHttpRequest();
xhr.open("GET", "https://newsapi.org/v1/articles?source=the-next-web&sortBy=latest&apiKey=883457e10266496c894218ba7d3f7baf", false);
xhr.send();

console.log(xhr.status);
console.log(xhr.statusText);
